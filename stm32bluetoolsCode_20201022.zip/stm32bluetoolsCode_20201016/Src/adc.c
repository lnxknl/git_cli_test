/**
  ******************************************************************************
  * File Name          : ADC.c
  * Description        : This file provides code for the configuration
  *                      of the ADC instances.
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "adc.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN 0 */
#include "systemINIT.h"
/* USER CODE END 0 */

ADC_HandleTypeDef hadc;

/* ADC init function */
void MX_ADC_Init(void)
{
  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure for the selected ADC regular channel to be converted. 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* ADC1 clock enable */
    __HAL_RCC_ADC1_CLK_ENABLE();
  
    /**ADC GPIO Configuration    
    PA0     ------> ADC_IN0 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ADC1 interrupt Init */
    HAL_NVIC_SetPriority(ADC1_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(ADC1_IRQn);
  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_ADC1_CLK_DISABLE();
  
    /**ADC GPIO Configuration    
    PA0     ------> ADC_IN0 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0);

    /* ADC1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(ADC1_IRQn);
  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
void ADC_Handle(void)
{
		unsigned char Message_BUF1[50] = {0};			//WIFI���ջ���

//    float mA_BUF;			//����ת��ֵ����
//    uint16_t i;
    if(REF_ADC_Flag == 1)
    {
        ADC_Value_BUF = ADC_Value;
			
					Message_BUF1[0] = 0x68;
					Message_BUF1[1] = 00;
					Message_BUF1[2] = 0x08;
					Message_BUF1[3] = 0x68;
					Message_BUF1[4] = 0x00;
					Message_BUF1[5] = 0x00;
					Message_BUF1[6] = 0x01;
					Message_BUF1[7] = 0x02;
					Message_BUF1[8] = 0x07;
					Message_BUF1[9] = 0x02;
					Message_BUF1[10] = ADC_Value_BUF >> 8;
					Message_BUF1[11] = ADC_Value_BUF;
					Message_BUF1[12] = 0x88;
					Message_BUF1[13] = 0x16;
					MODBUS_Send(Message_BUF1,14);
//        FHigh = (float)FHigh_CTrL.I;
//        FLOW = (float)FLOW_CTrL.I;
//        IHigh = (float)IHigh_CTrL;
//        ILOW = (float)ILOW_CTrL;
//        
//        Constant_a = (FHigh - FLOW)/(IHigh - ILOW);
//        Constant_b = FHigh - (Constant_a * IHigh);

//        if(ADC_Value_BUF >= ADC_Value)          //���� �ٽ��仯
//        {
//            i = ADC_Value_BUF - ADC_Value;
//        }
//        else
//        {
//            i = ADC_Value - ADC_Value_BUF;
//        }
////        if(ADC_Value != ADC_Value_BUF)
//        if((i >= ADCStep_Length)||(PowerOn_ADC_Flag == 1))
//        {
//            PowerOn_ADC_Flag = 0;
//             if(ADC_Value <= 2)
//            {
//                ADCValue_mAVAL = 0;
//            }
//            else
//            {
//                ADCValue_mAVAL = (float)ADC_Value / ADCValue_mACoeff + ADCValue_mAOffset;
//								//���Ƹ��޵���  ���޵���  Ʈ�ݵ�  ƫ����  ��λ��mA��
//							  if((ADCValue_mAVAL >= ILOW_MIN)&&((ADCValue_mAVAL - ILOW_MIN) <= mA_MINMAX_Offset))
//								{
//									ADCValue_mAVAL = ILOW_MIN - 0.1;
//								}
//								if((ADCValue_mAVAL < IHigh_MAX)&&((IHigh_MAX - ADCValue_mAVAL) <= mA_MINMAX_Offset))
//								{
//									ADCValue_mAVAL = IHigh_MAX + 0.1;
//								}							
//							
//            }
//            mA_BUF = ADCValue_mAVAL;            //��������ֵ ����

//             
//            FHigh = (float)FHigh_CTrL.I;
//            FLOW = (float)FLOW_CTrL.I;
//            IHigh = (float)IHigh_CTrL;
//            ILOW = (float)ILOW_CTrL;

////            Constant_a = (FHigh - FLOW)/(IHigh - ILOW);
////            Constant_b = FHigh - (Constant_a * IHigh);

////            ADCValue_mAVAL = ((Constant_a * ADCValue_mAVAL) + Constant_b);
////            if(ADCValue_mAVAL >= 0)
////            {
////								
////								if((ADCValue_mAVAL - (unsigned int)ADCValue_mAVAL) >= 0.5)
////								{
////									Pump_NOWmA_F = (unsigned int)ADCValue_mAVAL + 1;
////								}
////								else
////								{
////									Pump_NOWmA_F = (unsigned int)ADCValue_mAVAL;
////								}
////                
////            }
////            else
////            {
////                Pump_NOWmA_F = 0;
////            }
//            if((mA_BUF >= ILOW_MIN)&&(mA_BUF <= IHigh_MAX)&&(Pump_NOWmA_F <= Pump_MAX_F.I))
//            {
//                if((mA_BUF >= ILOW_MIN)&&(mA_BUF <= ILOW_CTrL))
//                {
//                    Pump_NOWmA_F = FLOW_CTrL.I;
//                }
//                if((mA_BUF >= IHigh_CTrL)&&(mA_BUF <= IHigh_MAX))
//                {
//                    Pump_NOWmA_F = FHigh_CTrL.I;
//                }
//                Pump_OFF_Time = (((60000/Pump_NOWmA_F)*10) - Pump_Dowd_Time );
//                if(((I_O1_SET == 0)&&(Open_Shut1 == 1))||((I_O1_SET == 1)&&(Open_Shut1 == 0)))
//                {
//                    if(Pump_OFF_Time >= 500)        //�ض�ʱ�䲻�ܵ����㣬������ͻ��ձ��գ������ʼ�����ϣ��յ����
//                    {
//                        Pump_ON_OFF = 1;
//                        Display_BCD_BUF[0] = 0x0A;          /* ��A��*/
//                        Pluse_REFDSP_Flag = 1;      //������˸
//                    }
//                }
//                
//                
//            }
//            else
//            {
//                Pump_ON_OFF = 0;
//                Display_BCD_BUF[0] = 0x0A;          /* ��A��*/
//                Pluse_REFDSP_Flag = 0;      //������˸
//            }
//            
//            if((Pump_A_M == 1)&&(MENU1 == 0))          //Pump_A_M  �� �ֶ� �Զ����ơ�0��Ϊ�ֶ���1��Ϊ�Զ�
//            {
//                REF_Display_flag = 1;               //��Ҫˢ����ʾ���� ��־λ
//                Display_BUF1 = Pump_NOWmA_F;
//        //        Display_BUF1 = ADC_Value;
////                Display_BCD_BUF[0] = 0x0F;        
//            }
//            
//            ADC_Value_BUF = ADC_Value;

//        }
//       

        REF_ADC_Flag = 0;
    }
}
/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
