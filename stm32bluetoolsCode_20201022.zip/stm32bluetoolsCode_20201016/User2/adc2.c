#include "pic.h"
#include <xc.h>
#include "pic16f1939.h"
#include "ADC.h"
#include "GenericTypeDefs.h"
#include "SystemINIT.h"
extern volatile unsigned char Transmit_Data[10];



void ADC_Init(void)
{
    TRISEbits.TRISE0 = 1;
    ANSELEbits.ANSE0 = 1;
    
   
    ADCON1bits.ADCS = 5;              // FOSC/16
    ADCON1bits.ADFM = 1;              //1 = �Ҷ��롣 װ��ת�����ʱ�� ADRESH �ĸ� 6 λ������Ϊ 0��
    ADCON1bits.ADNREF = 0;            //0 = VREF- �� VSS ����
    ADCON1bits.ADPREF = 00;           //00 = VREF+ �� VDD ����
    
    ADCON0bits.CHS = 0x05;            //ͨ�� AN5 =  RE0
    ADCON0bits.ADON = 1;              //1 = ADC ��ʹ��
    
    PIR1bits.ADIF=0;                    // ���� ADC �жϱ�־    
    PIE1bits.ADIE=1;                    //  ���� ADC �ж�
    INTCONbits.PEIE=1;                  //���������ж�
    INTCONbits.GIE=1;                   //����ȫ���ж� 
    
    
    
}


void ADC_Handle(void)
{
    float mA_BUF;
    INT16 i;
    if(REF_ADC_Flag == 1)
    {
        
//        FHigh = (float)FHigh_CTrL.I;
//        FLOW = (float)FLOW_CTrL.I;
//        IHigh = (float)IHigh_CTrL;
//        ILOW = (float)ILOW_CTrL;
//        
//        Constant_a = (FHigh - FLOW)/(IHigh - ILOW);
//        Constant_b = FHigh - (Constant_a * IHigh);

        if(ADC_Value_BUF >= ADC_Value)          //���� �ٽ��仯
        {
            i = ADC_Value_BUF - ADC_Value;
        }
        else
        {
            i = ADC_Value - ADC_Value_BUF;
        }
//        if(ADC_Value != ADC_Value_BUF)
        if((i >= 2)||(PowerOn_ADC_Flag == 1))
        {
            PowerOn_ADC_Flag = 0;
             if(ADC_Value <= 2)
            {
                ADCValue_mAVAL = 0;
            }
            else
            {
                ADCValue_mAVAL = (float)ADC_Value / ADCValue_mACoeff;
            }
            mA_BUF = ADCValue_mAVAL;            //��������ֵ ����

             
            FHigh = (float)FHigh_CTrL.I;
            FLOW = (float)FLOW_CTrL.I;
            IHigh = (float)IHigh_CTrL;
            ILOW = (float)ILOW_CTrL;

            Constant_a = (FHigh - FLOW)/(IHigh - ILOW);
            Constant_b = FHigh - (Constant_a * IHigh);

            ADCValue_mAVAL = ((Constant_a * ADCValue_mAVAL) + Constant_b);
            if(ADCValue_mAVAL >= 0)
            {
                Pump_NOWmA_F = (unsigned int)ADCValue_mAVAL;
            }
            else
            {
                Pump_NOWmA_F = 0;
            }
            if((mA_BUF >= ILOW_MIN)&&(mA_BUF <= IHigh_MAX)&&(Pump_NOWmA_F <= Pump_MAX_F.I))
            {
                if((mA_BUF >= ILOW_MIN)&&(mA_BUF <= ILOW_CTrL))
                {
                    Pump_NOWmA_F = FLOW_CTrL.I;
                }
                if((mA_BUF >= IHigh_CTrL)&&(mA_BUF <= IHigh_MAX))
                {
                    Pump_NOWmA_F = FHigh_CTrL.I;
                }
                Pump_OFF_Time = (((60000/Pump_NOWmA_F)*10) - Pump_Dowd_Time );
                if(((I_O1_SET == 0)&&(Open_Shut1 == 1))||((I_O1_SET == 1)&&(Open_Shut1 == 0)))
                {
                    if(Pump_OFF_Time >= 500)        //�ض�ʱ�䲻�ܵ����㣬������ͻ��ձ��գ������ʼ�����ϣ��յ����
                    {
                        Pump_ON_OFF = 1;
                        Display_BCD_BUF[0] = 0x0A;          /* ��A��*/
                        Pluse_REFDSP_Flag = 1;      //������˸
                    }
                }
                
                
            }
            else
            {
                Pump_ON_OFF = 0;
                Display_BCD_BUF[0] = 0x0A;          /* ��A��*/
                Pluse_REFDSP_Flag = 0;      //������˸
            }
            
            if((Pump_A_M == 1)&&(MENU1 == 0))          //Pump_A_M  �� �ֶ� �Զ����ơ�0��Ϊ�ֶ���1��Ϊ�Զ�
            {
                REF_Display_flag = 1;               //��Ҫˢ����ʾ���� ��־λ
                Display_BUF1 = Pump_NOWmA_F;
        //        Display_BUF1 = ADC_Value;
//                Display_BCD_BUF[0] = 0x0F;        
            }
            
            ADC_Value_BUF = ADC_Value;

        }
       

        REF_ADC_Flag = 0;
    }
}

