#include "SystemINIT.h"
#ifndef __MODBUS_COM_H
#define __MODBUS_COM_H








void MODBUS_DO(void);
uint16_t CRC16_Check(uint8_t *Pushdata,uint8_t length); 






#endif    //__MODBUS_COM_H
