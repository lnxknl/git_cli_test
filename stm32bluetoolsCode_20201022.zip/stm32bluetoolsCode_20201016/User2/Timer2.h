#ifndef __Timer2_H
#define __Timer2_H







void INIT_Timer2(void);


#endif   //__Timer2_H