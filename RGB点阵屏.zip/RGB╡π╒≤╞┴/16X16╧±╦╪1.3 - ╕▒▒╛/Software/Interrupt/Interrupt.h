#ifndef __Interrupt_H
#define __Interrupt_H

extern u8 Get_Num;

void Interrupt_Init(void);				//中断初始化


#endif

