#include "stm32f10x.h"                  // Device header
#include "Interrupt.h"
#include "USART.h"
#include "WS2812B.h"

/** @brief	中断初始化
  **/
void Interrupt_Init(void)
{
	//中断组选择
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);		//NVIC中断组2
	
	//中断初始化
	USART1_Interrupt_Init(1,1);
}


/*
↓↓↓↓↓↓↓↓↓↓中断函数↓↓↓↓↓↓↓↓↓↓
													*/
u8 Get_Num;

/** @brief	USART1中断函数
  **/
void USART1_IRQHandler(void)
{
	static u8 *P_Light_Data=&Light_Data[0][0];				//静态指针变量，指向数组Light_Data的首地址
	*P_Light_Data=(USART_ReceiveData(USART1)/1);			//转移变量至数组Light_Data
	P_Light_Data++;																		//指针自增
	if(P_Light_Data==&Light_Data[127][3])
	{	P_Light_Data=&Light_Data[0][0];}								//溢出操作判断
	
	USART_ClearITPendingBit(USART1,USART_IT_RXNE);		//清除标志位
}




