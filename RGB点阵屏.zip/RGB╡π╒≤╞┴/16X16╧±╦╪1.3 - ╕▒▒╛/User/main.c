/********************************************************************
***此程序使用USART接收数据，IO口直接输出数据至WS2812B
***由于是IO直接输出数据，严禁使用中断，否则会导致IO输出数据混乱
***若仍需使用中断，需将数据发送函数放置在更高优先级函数内
***
***USART接收的数据由DMA搬运至缓存区
***IO发送数据时严禁打断
***IO数据发送完成后150us内不得再次发送，
***否则WS2812B会认为数据未发送完成，会将此数据转移至下一个灯上
***IO口默认为低电平
***
***Write By Ideal_Fox
********************************************************************/
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "WS2812B.h"
#include "USART.h"
#include "LED.h"
#include "ADC.h"

u16 USART_Data[256][3];			//USART数据缓存区，长度：0.75KB

///////////////////////////////////////////////////////////////////////////////////////////////////

// 定义圆环动画的参数
#define MATRIX_SIZE 16
#define RING_WIDTH 3
#define ANIMATION_DURATION_MS 5000  // 动画持续时间为5秒，每5ms更新一次

// 计算平方值
static uint8_t square(uint8_t x) {
    return x * x;
}

// 计算圆环的RGB值
void calculateRingAnimation() {
    static uint16_t animationCounter = 0;
    uint8_t centerR = 255;  // 中心点颜色为红色
    uint8_t centerG = 0;
    uint8_t centerB = 0;
    uint8_t ringR = 0;      // 圆环颜色为绿色
    uint8_t ringG = 255;
    uint8_t ringB = 0;

    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            uint8_t dx = i - MATRIX_SIZE / 2;
            uint8_t dy = j - MATRIX_SIZE / 2;
            uint8_t distanceToCenterSquared = square(dx) + square(dy);
            
            if (distanceToCenterSquared < square(RING_WIDTH)) {
                // 在圆环内
                USART_Data[i * MATRIX_SIZE + j][0] = ringR;
                USART_Data[i * MATRIX_SIZE + j][1] = ringG;
                USART_Data[i * MATRIX_SIZE + j][2] = ringB;
            } else if (distanceToCenterSquared < square(RING_WIDTH + 3)) {
                // 圆环外边缘
                USART_Data[i * MATRIX_SIZE + j][0] = centerR;
                USART_Data[i * MATRIX_SIZE + j][1] = centerG;
                USART_Data[i * MATRIX_SIZE + j][2] = centerB;
            } else {
                // 圆环外
                USART_Data[i * MATRIX_SIZE + j][0] = 0;
                USART_Data[i * MATRIX_SIZE + j][1] = 0;
                USART_Data[i * MATRIX_SIZE + j][2] = 0;
            }
        }
    }

    animationCounter += 5;  // 每5ms更新一次
    if (animationCounter >= ANIMATION_DURATION_MS) {
        animationCounter = 0;  // 重置计数器，重新开始动画
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////

int main(void)
{
	LED_Init();													//LED初始化
	LED_State(ON);											//开启LED
	WS2812_GPIO_Init();									//WS2812初始化
//	USART1_Init();											//USART1初始化
//	USART1_DMA_Init((u32)&USART_Data[0][0]);	//USART1,DMA初始化
	ADC_ALL_Init();											//ADC初始化
	
	while(1)
	{
		
		calculateRingAnimation();
		USART_DMA_Handle(&USART_Data[0][0],&Light_Data[0][0],AD_Value_convert());		//USART数据处理
		WS2812_256_Loop_Turn();
		Delay_ms(5);
	}
		
	
}

