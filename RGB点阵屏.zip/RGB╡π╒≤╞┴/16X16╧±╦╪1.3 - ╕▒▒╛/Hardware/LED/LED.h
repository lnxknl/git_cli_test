#ifndef __LED_H
#define __LED_H

#define  ON  1
#define	 OFF 0


void LED_Init(void);						//LED初始化

void LED_State(u8 state);				//LED操作

#endif
