#include "stm32f10x.h"                  // Device header
#include "LED.h"

/** @brief	LED初始化，PC13
  * @param	无
  * @retval	无
  **/
void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);				//GPIOB使能
	
	//初始化结构体
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;						//推挽输出		
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_13;									//5号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;						//翻转速度50MHz
	
	GPIO_Init(GPIOC,&GPIO_InitStructure);												//初始化GPIOB端口
	GPIO_SetBits(GPIOC,GPIO_Pin_13);															//LED初始状态,灭
}

/** @brief	LED显示状态
	* @param	0，灭		1，亮
  * @retval	无
  **/
void LED_State(u8 state)
{
	if(state)
	{	GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_RESET);}
	else
	{	GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_SET);}
}
