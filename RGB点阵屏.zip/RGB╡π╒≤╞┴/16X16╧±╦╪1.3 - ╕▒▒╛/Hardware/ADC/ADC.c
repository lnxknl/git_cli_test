#include "stm32f10x.h"                  // Device header
#include "ADC.h"
#include "Delay.h"

u16 AD_Value;
//存放ADC值

/** @brief	ADC输入GPIO初始化PA0
  **/
void ADC_GPIO_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode		=GPIO_Mode_AIN;					//模拟输入
	GPIO_InitStruct.GPIO_Pin		=GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Speed	=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
}

/** @brief	ADC1初始化，单通道
  **/
void ADC1_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);					//使能ADC1
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);														//ADC8分频 72M/8=9M

	ADC_RegularChannelConfig(ADC1,ADC_Channel_0,1,ADC_SampleTime_239Cycles5);	
	//ADC1,通道0，序列1，采样周期239.5
	
	//ADC初始化结构体
	ADC_InitTypeDef ADC_InitStruct;
	ADC_InitStruct.ADC_DataAlign					=ADC_DataAlign_Right;								//数据右对齐
	ADC_InitStruct.ADC_ExternalTrigConv		=ADC_ExternalTrigConv_None;					//软件触发
	ADC_InitStruct.ADC_Mode								=ADC_Mode_Independent;							//独立转换模式
	ADC_InitStruct.ADC_ContinuousConvMode	=ENABLE;														//连续转换
	ADC_InitStruct.ADC_ScanConvMode				=DISABLE;														//多通道
	ADC_InitStruct.ADC_NbrOfChannel				=1;																	//通道数1
	ADC_Init(ADC1,&ADC_InitStruct);
	
	ADC_Cmd(ADC1,ENABLE);																	//开启ADC1

	ADC_ResetCalibration(ADC1);														//复位ADC1
	while(ADC_GetResetCalibrationStatus(ADC1)==SET);
	ADC_StartCalibration(ADC1);														//校准ADC1
	while(ADC_GetCalibrationStatus(ADC1)==SET);
}

/** @brief	DMA1通道1初始化
  **/
void ADC_DMA_Init(void)
{
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);		//使能DMA1
	
	DMA_InitTypeDef DMA_InitStruct;
	//源数据
	DMA_InitStruct.DMA_PeripheralBaseAddr	=(u32)&ADC1->DR;									//源数据地址
	DMA_InitStruct.DMA_PeripheralDataSize	=DMA_PeripheralDataSize_HalfWord;	//源数据长度
	DMA_InitStruct.DMA_PeripheralInc			=DMA_PeripheralInc_Disable;				//数据不自增
	//目标数据
	DMA_InitStruct.DMA_MemoryBaseAddr			=(u32)&AD_Value;									//目标数据地址
	DMA_InitStruct.DMA_MemoryDataSize			=DMA_MemoryDataSize_HalfWord;			//目标数据长度
	DMA_InitStruct.DMA_MemoryInc					=DMA_MemoryInc_Enable;						//数据自增
	//DMA设置
	DMA_InitStruct.DMA_Mode								=DMA_Mode_Circular;								//循环模式
	DMA_InitStruct.DMA_BufferSize					=1;																//转运次数
	DMA_InitStruct.DMA_DIR								=DMA_DIR_PeripheralSRC;						//源至目标
	DMA_InitStruct.DMA_M2M								=DMA_M2M_Disable;									//硬件触发
	DMA_InitStruct.DMA_Priority						=DMA_Priority_High;								//高优先级
	DMA_Init(DMA1_Channel1,&DMA_InitStruct);		//DMA1通道1初始化
	
	DMA_Cmd(DMA1_Channel1, ENABLE);							//开启DMA1
	ADC_DMACmd(ADC1,ENABLE);										//开启ADC至DMA通道
}

/** @brief	ADC1开始转换
  **/
void ADC1_Start(void)
{
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);				//ADC1开始转换
}

/** @brief	ADC模块初始化
  **/
void ADC_ALL_Init(void)
{
	ADC_GPIO_Init();					//ADC输入GPIO初始化
	ADC1_Init();							//ADC1初始化，单通道
	ADC_DMA_Init();						//DMA1通道1初始化
	ADC1_Start();							//ADC1开始转换
}

/** @brief	获取AD转换值	
  * @retval	AD转换值	
  **/
float AD_Value_convert(void)
{
	u16 Value_convert=AD_Value;
	return ((float)Value_convert/200)+1;
}






