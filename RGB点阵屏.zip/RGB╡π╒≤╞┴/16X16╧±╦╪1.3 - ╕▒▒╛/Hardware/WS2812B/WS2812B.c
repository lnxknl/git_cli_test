#include "stm32f10x.h"                  // Device header
#include "WS2812B.h"
#include "Delay.h"

u8 Light_Data[256][3];

/** @brief	GPIO输出初始化
  **/
void WS2812_GPIO_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode		=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin		=GPIO_Pin_12;
	GPIO_InitStruct.GPIO_Speed	=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET);
}

/** @brief	空函数，延时200ns
  **/
void Delay_air(void){}

/** @brief	GPIO输出
	* @param	发送的数据
  **/
void GPIO_Write_Bit(u8 Bit)
{
	if(Bit==0)
	{	GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET);				//置1
//		Delay_air();																	//延时0.28us
		GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);			//置0
		for(u8 i=0;i<4;i++){Delay_air();}								//延时1.72us
	}
	else
	{	GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET);				//置1
		for(u8 i=0;i<3;i++){Delay_air();}								//延时0.9us
		GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);			//置0
		for(u8 i=0;i<2;i++){Delay_air();}								//延时1.1us
	}
	//GPIO端口翻转一次需200ns
}

/** @brief	WS2812B发送数据
	* @param	R:红灯，G:绿灯，B:蓝灯
  **/
void WS2812B_Write(u8 R,u8 G,u8 B)
{
	for(u8 i=0;i<8;i++)
	{	GPIO_Write_Bit(G&(0X80>>i));}
	for(u8 i=0;i<8;i++)
	{	GPIO_Write_Bit(R&(0X80>>i));}
	for(u8 i=0;i<8;i++)
	{	GPIO_Write_Bit(B&(0X80>>i));}
	//WS2812B数据顺序为GRB，接收顺序为高至低位
}

/** @brief	发送256个RGB数据至WS2812B
  **/
void WS2812_256_Loop(void)
{
	u8 *P_Light_Data=&Light_Data[0][0];			//定义指针，指向数组Light_Data的首地址
	u8 *P_Light_Data_R,*P_Light_Data_G,*P_Light_Data_B;
	for(u16 i=0;i<256;i++)
	{
		P_Light_Data_R=(P_Light_Data++);
		P_Light_Data_G=(P_Light_Data++);
		P_Light_Data_B=(P_Light_Data++);
		WS2812B_Write(*P_Light_Data_R,*P_Light_Data_G,*P_Light_Data_B);
	}	//发送数据，循环执行128次
}	

/** @brief	发送256个RGB数据至WS2812B		数据从高至低发送
  **/
void WS2812_256_Loop_Turn(void)
{
	u8 *P_Light_Data=&Light_Data[255][2];			//定义指针，指向数组Light_Data的末地址
	u8 *P_Light_Data_R,*P_Light_Data_G,*P_Light_Data_B;
	for(u16 i=0;i<256;i++)
	{
		P_Light_Data_B=(P_Light_Data--);
		P_Light_Data_G=(P_Light_Data--);
		P_Light_Data_R=(P_Light_Data--);
		WS2812B_Write(*P_Light_Data_R,*P_Light_Data_G,*P_Light_Data_B);
	}	//发送数据，循环执行128次
}	












