#ifndef __WS2812B_H
#define __WS2812B_H


extern u8 Light_Data[64][3];										//数据缓存数组

void WS2812_GPIO_Init(void);										//GPIO输出初始化
void WS2812B_Write(u8 R,u8 G,u8 B);							//WS2812B发送数据
void WS2812_64_Loop(void);											//发送128个RGB数据至WS2812B
	

#endif


