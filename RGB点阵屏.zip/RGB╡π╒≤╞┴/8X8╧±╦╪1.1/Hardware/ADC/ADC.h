#ifndef __ADC_H
#define __ADC_H

extern u16 AD_Value;

void ADC_ALL_Init(void);								//ADC模块初始化
void ADC1_Start(void);									//ADC1开始转换

#endif


