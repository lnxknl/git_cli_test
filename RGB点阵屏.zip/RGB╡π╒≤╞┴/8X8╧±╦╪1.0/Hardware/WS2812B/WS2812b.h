#ifndef __WS2812B_H
#define __WS2812B_H


extern u8 Light_Data[64][3];

void WS2812_GPIO_Init(void);
void WS2812B_Write(u8 R,u8 G,u8 B);
void WS2812B_Reset(void);
void WS2812_64_Loop(void);
	

#endif


