#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "WS2812B.h"
#include "USART.h"
#include "LED.h"
#include "Interrupt.h"

u8 State,State1;

int main(void)
{
	LED_Init();								//LED初始化
	LED_State(ON);						//开启LED
	WS2812_GPIO_Init();				//WS2812初始化
	USART1_Init();						//USART1初始化
	Interrupt_Init();					//中断初始化
	
	while(1)
	{
		
		WS2812_64_Loop();
		Delay_ms(5);
	}
		
	
}

