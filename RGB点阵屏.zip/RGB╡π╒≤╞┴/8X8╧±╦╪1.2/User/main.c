/********************************************************************
***此程序使用USART接收数据，IO口直接输出数据至WS2812B
***由于是IO直接输出数据，严禁使用中断，否则会导致IO输出数据混乱
***若仍需使用中断，需将数据发送函数放置在更高优先级函数内
***
***USART接收的数据由DMA搬运至缓存区
***根据ADC值处理缓存区数据，并转移数据至发送区
***IO发送数据时严禁打断
***IO数据发送完成后150us内不得再次发送，
***否则WS2812B会认为数据未发送完成，会将此数据转移至下一个灯上
***IO口默认为低电平
***
***Write By Ideal_Fox
********************************************************************/
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "WS2812B.h"
#include "USART.h"
#include "LED.h"
#include "ADC.h"

u8 USART_Data[64][3];			//USART数据缓存区，长度：0.75KB

int main(void)
{
	LED_Init();																//LED初始化
	LED_State(ON);														//开启LED
	WS2812_GPIO_Init();												//WS2812初始化
	USART1_Init();														//USART1初始J化
	USART1_DMA_Init((u32)&USART_Data[0][0]);	//USART1,DMA初始化
	ADC_ALL_Init();														//ADC初始化
	
	while(1)
	{
		USART_DMA_Handle(&USART_Data[0][0],&Light_Data[0][0],AD_Value_convert());		//USART数据处理
		WS2812_64_Loop();			//发送数据
		Delay_ms(5);
	}
		
	
}

