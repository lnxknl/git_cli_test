#ifndef _uart_
#define _uart_


//#include "serial.h"
#include "string.h"
//#include "my_tcp.h"

#define WIFI_BUF_LEN	256

static uint8_t wifi_buf[WIFI_BUF_LEN];			//wifi数据缓存

static uint16_t wifi_index=0;							//wifi缓存索引



/*/////////////////协议定义//////////////////////

	//初步协议定义

			 0				1				2		 3					n				254max		255max
			0x6b  	0xb6 		type 	lenh			ndata  		count  			sum
			数据头		数据头		类型	长度			数据			数据计数			
			
	*/

//针头
#define ZT1 0x6B
#define ZT2 0xB6


///////////////////////////////////////////////

校验数据
uint8_t check_wifi_data();

//添加数据到缓存
void  wifi_buf_add(uint8_t ch);

//获取当前数据长度
uint16_t get_wifi_buf_len();

//清空数据
void clear_wifi_buf();

#endif
