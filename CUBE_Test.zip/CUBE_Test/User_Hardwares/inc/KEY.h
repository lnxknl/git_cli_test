#ifndef __KEY_H__
#define __KEY_H__

#include "main.h"

#define S_KEY1 HAL_GPIO_ReadPin(S_KEY1_GPIO_Port, S_KEY1_Pin)
#define S_KEY2 HAL_GPIO_ReadPin(S_KEY2_GPIO_Port, S_KEY2_Pin)

void Key_Init(void);
uint8_t Key_Scan(void);
uint8_t Matrix_key_scan(void);

#endif


