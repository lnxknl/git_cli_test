#ifndef __EXTI_H__
#define __EXTI_H__

#include "stm32f10x.h"
void EXTI_Config(void);


#endif

