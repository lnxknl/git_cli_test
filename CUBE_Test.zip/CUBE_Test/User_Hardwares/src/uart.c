
//#include "uart.h"


////添加数据到缓存
//void  wifi_buf_add(u8 ch)
//{
//	
//	if(wifi_index>=WIFI_BUF_LEN-1)
//	return;
//	
//	wifi_buf[wifi_index++]=ch;
//	
//	wifi_buf[wifi_index]=0;
//}

////获取当前数据长度
//u16 get_wifi_buf_len()
//{
//	
//	return wifi_index;
//	
//}

////清空数据
//void clear_wifi_buf()
//{
//	
//	wifi_index=0;
//	
//}
////发生数据包
//static void send_data()
//{
//	//前面需要先准备好数据
//	
//	
//	//是否要发送数据
//	if(wifi_mes.send_len)
//	{
//		serial2_sned_buff(wifi_mes.send_data,wifi_mes.send_len);
//		wifi_mes.send_len=0;		//发送完后清零避免多次发送
//	}
//	//如果没有准备数据，则发送ack
//	else
//	{
//		serial2_sned_buff((u8*)"wifi_hes\r\n",10);
//		
//	}
//}

////处理解析数据
//static void wifi_tran_data()
//{
//	//处理数据类型
//	switch(wifi_mes.type)
//	{
//		//--------------下面是处理协议对应事件---------------------
//		case 0x01:
//			
//			break;
//		case 0x02:
//			
//			break;
//		case 0x03:
//			
//			break;
//		case 0x04:
//			
//			break;
//		case 0x05:
//			
//			break;
//		case 0x06:
//			
//			break;
//		case 0x07:
//			
//			break;
//		
//	}
//	
//}

////检查命令
//u8 check_wifi_data()
//{
//	u8 v=0;
//	
//	if(wifi_index>=1)
//	{
//		v=data_check(wifi_buf,&wifi_mes);
//		//printf("data_len:%s  %d\r\n",wifi_buf,wifi_index);
//		
//	}

//	//如果解析到数据
//	if(v)
//	{
//		clear_wifi_buf();		//清空缓存
//		
//		wifi_tran_data();		//根据协议处理数据
//		
//		send_data();
//		
//		
//		
//	}
//	else
//	{
//		//如果数据丢包或者乱码，发送erro
//		wifi_mes.recv_len=0;
//		//if(wifi_index!=0)
//		//serial2_sned_buff((u8*)"wifi_erro\r\n",10);
//		
//	}

//	return 0;
//}
