#include "serial_config.h"
#include "string.h"
#include "stdio.h"
//#include "stm32f10x.h"


//在缓冲中寻找命令并清空缓冲
//参数：mes：接收缓冲，str：命令,en_clear:是否清空缓冲
//查找到命令返回1，否则0
unsigned char find_str_del(char *str,unsigned char en_clear)
{
	unsigned char res = 0;
	if(strstr(mes_buf,str)!=NULL)	//找到对应字符串
	{
		res = 1;			//返回1,否则返回0
	}
	if(en_clear)
	{
		num = 0;			//接收下标清零
		clear_mes_buf();	//清空缓冲
	}
	return res;
}

//添加数据到队列
void add_mes_buf(char ch)
{
	mes_buf[num++]=ch;

	if(num==MES_LEN)num=0;
}

//清空接收缓冲
void clear_mes_buf(void)
{
	memset(mes_buf,0,MES_LEN);	//清空接收缓冲
}
