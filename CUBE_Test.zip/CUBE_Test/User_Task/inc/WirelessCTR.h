#ifndef __SHOW_H__
#define __SHOW_H__
#include "main.h"

#define UNK_STA 0

extern uint8_t server_sta;		//������״̬��־λ
extern uint8_t wifi_sta;		//wifi״̬��־λ
extern uint8_t gprs_sta;		//gprs״̬��־λ
typedef enum
{
	SERVER_OFF_LINE = 1,
	SERVER_ON_LINE,
}server_sta_e;

typedef enum
{
	
	WIFI_OFF_LINE = 1,
	WIFI_ON_LINE,
}wifi_sta_e;

typedef enum
{
	GPRS_OFF_LINE = 1,
	GPRS_ON_LINE,
}gprs_sta_e;

#endif
