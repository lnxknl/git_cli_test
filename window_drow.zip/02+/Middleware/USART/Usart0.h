#ifndef __USART0_H__
#define __USART0_H__

#include "gd32f4xx.h"

#define USART0_RECV_CALLBACK 	0
#define USART0_PRINTF		 			1

#if	USART0_PRINTF
#include <stdio.h>
#endif


//��ʼ��
void Usart0_init(unsigned int bund);
//��������
void Usart0_send_byte(uint8_t data);
void Usart0_send_string(char *data);

//��������
#if USART0_RECV_CALLBACK 
extern void Usart0_recv(uint8_t *data, uint32_t len);
#endif


#endif