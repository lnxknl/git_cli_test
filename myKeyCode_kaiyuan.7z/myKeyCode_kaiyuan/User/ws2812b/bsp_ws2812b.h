#ifndef __WS2812B_H
#define	__WS2812B_H

#include "stm32f10x.h"


#define TIMING_ONE  61
#define TIMING_ZERO 29



void Timer1_init(void);
void WS2812_send(uint8_t color[3], uint16_t len);




#endif /* __WS2812B_H */
