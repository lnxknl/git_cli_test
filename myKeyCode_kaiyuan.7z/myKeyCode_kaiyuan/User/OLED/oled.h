#ifndef __OLED_H
#define __OLED_H	

#include "sys.h"
#include "bsp_SysTick.h"

#define SDA_IN()  {GPIOB->CRH&=~(0X0F<<12);GPIOB->CRH|=(u32)8<<12;}
#define SDA_OUT() {GPIOB->CRH&=~(0X0F<<12);GPIOB->CRH|=(u32)3<<12;}


#define IIC_SCL    PBout(10) //SCL
#define IIC_SDA    PBout(11) //SDA	 
#define READ_SDA   PBin(11)  //����SDA

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����


#define Max_Column	128
#define Max_Row		32
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	32	 

void OLED_Init(void);

u8 IIC_Read_Byte(unsigned char ack);
void IIC_Send_Byte(u8 txd);
void IIC_NAck(void);
void IIC_Ack(void);
u8 IIC_Wait_Ack(void);
void IIC_Stop(void);
void IIC_Start(void);

void Write_IIC_Command(unsigned char IIC_Command);
void Write_IIC_Data(unsigned char IIC_Data);

void OLED_WR_Byte(unsigned dat,unsigned cmd);

void OLED_Set_Pos(unsigned char x, unsigned char y) ;
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void)  ;
void OLED_On(void)  ;

void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);

void OLED_ShowString(u8 x,u8 y,u8 *chr,u8 Char_Size);
void OLED_ShowCHinese(u8 x,u8 y,u8 no);

void OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);


#endif  
	 
