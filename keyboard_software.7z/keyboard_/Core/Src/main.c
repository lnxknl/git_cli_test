#include "main.h"
#include "hal_usb_core.h"
#include "spi.h"
#include "keyboard.h"

int main()
{
	NVIC_SetPriorityGrouping(4);

	RCC->APB2ENR |= RCC_APB2ENR_AFIOEN;
	RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;

	hal_usb_init();
	spi_init();
	keyboard_handle();
	for(;;)
	{

	}
}
