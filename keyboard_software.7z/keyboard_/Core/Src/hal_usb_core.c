#include "hal_usb_core.h"
#include "hal_usb_descriptor.h"



#define EP_COUNT        2U


const usb_ep_t usb_ep_list[EP_COUNT] = 
{
    {
        .ep_idx = 0,
        .ep_type = USB_EP_CONTROL,
        .in_buf_status = USB_EP_TX_NAK,
        .in_buf_addr = 64U,
        .out_buf_status = USB_EP_RX_VALID,
        .out_buf_addr = 128U
    },
    {
        .ep_idx = 1,
        .ep_type = USB_EP_INTERRUPT,
        .in_buf_status = USB_EP_TX_VALID,
        .in_buf_addr = 192U,
        .out_buf_status = USB_EP_RX_DIS,
        .out_buf_addr = 0
    }
};

const usb_obj_t usb_obj = {
    .ep_count = EP_COUNT,
    .ep_list = (usb_ep_t *)usb_ep_list
};


static void ep0_func();
static void ep1_func();



void hal_usb_init()
{
	NVIC_SetPriority(USB_LP_CAN1_RX0_IRQn,6);
	NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
	RCC->APB1ENR |= RCC_APB1ENR_USBEN;
	USB->CNTR = 0;
    /* reset */
    USB->CNTR |= USB_CNTR_FRES;
    USB->CNTR &= ~USB_CNTR_FRES;
	while((USB->ISTR & USB_ISTR_RESET) != USB_ISTR_RESET){}
	USB->ISTR &= ~USB_ISTR_RESET;


	USB->CNTR |= USB_CNTR_CTRM
				|USB_CNTR_ERRM
				|USB_CNTR_WKUPM
				|USB_CNTR_SUSPM
				|USB_CNTR_RESETM
				|USB_CNTR_SOFM
				|USB_CNTR_ESOFM;
}


static void usb_write_ep_buf(uint8_t *data,uint32_t buf_offset,uint32_t length)
{
  volatile uint16_t *pdwVal;
  uint16_t i = 0;
  uint16_t n = 0;
  pdwVal = (volatile uint16_t *)(USB_PMAADDR + ((uint32_t)buf_offset * 2));
  n = (length+1) >> 1;
  for (i = n; i != 0U; i--)
  {
    *pdwVal = *data;
    data++;
    *pdwVal = *pdwVal | ((uint16_t)((uint16_t) *data << 8));
    pdwVal+=2;
    data++;
  }
}


static void usb_read_ep_buf(uint8_t *data,uint32_t buf_offset,uint32_t length)
{
  volatile uint16_t *pdwVal;
  uint16_t i = 0;
  uint16_t n = 0;
  pdwVal = (volatile uint16_t *)(USB_PMAADDR + ((uint32_t)buf_offset * 2));
  n = length >> 1;
  for (i = n; i != 0U; i--)
  {
    *data = (uint8_t)(*pdwVal & 0xFFU);
    data++;
    *data = (uint8_t)((*pdwVal >> 8) & 0xFFU);
    data++;
    pdwVal+=2;
  }
  if ((length % 2U) != 0U)
  {
    *data = (uint8_t)(*pdwVal & 0xFFU);
  }  
}

static void usb_clear_eptx_flag(uint32_t epNum)
{
    uint16_t wRegVal = 0;
    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk )
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_RX_Msk);
}

static void usb_clear_eprx_flag(uint32_t epNum)
{
    uint16_t wRegVal = 0;
    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk )
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_TX_Msk);
}

static void usb_set_eptx_status(uint32_t epNum,uint32_t epStatus)
{
    uint16_t wRegVal = 0;

    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk 
                    | USB_EPTX_STAT_Msk)
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_TX | USB_EP_CTR_RX);

    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk 
                    | USB_EPTX_STAT_Msk)
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_TX | USB_EP_CTR_RX | epStatus);
}

static void usb_set_eprx_status(uint16_t epNum,uint32_t epStatus)
{
    uint16_t wRegVal = 0;
    
    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk 
                    | USB_EPRX_STAT_Msk)
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_TX | USB_EP_CTR_RX);

    wRegVal = ((USB_GET_ENDPOINT(epNum))
                & (USB_EPADDR_FIELD_Msk 
                    | USB_EP_KIND_Msk 
                    | USB_EP_T_FIELD_Msk 
                    | USB_EPRX_STAT_Msk)
                );
    USB_SET_ENDPOINT(epNum,wRegVal | USB_EP_CTR_TX | USB_EP_CTR_RX | epStatus);
}

static void hal_usb_ctrm_irq();
static void hal_usb_reset_irq();
static void hal_usb_err_irq();
static void hal_usb_wkup_irq();
static void hal_usb_susp_irq();
static void hal_usb_sof_irq();
static void hal_usb_esof_irq();

void USB_LP_CAN1_RX0_IRQHandler()
{
  uint16_t regVal = USB->ISTR;
  if(regVal & USB_ISTR_CTR)
  {
    hal_usb_ctrm_irq();
  }
  if(regVal & USB_ISTR_RESET)
  {
    hal_usb_reset_irq();
  }
  if(regVal & USB_ISTR_ERR)
  {
    hal_usb_err_irq();
  }
  if(regVal & USB_ISTR_WKUP)
  {
    hal_usb_wkup_irq();
  }
  if(regVal & USB_ISTR_SUSP)
  {
    hal_usb_susp_irq();
  }
  if(regVal & USB_ISTR_SOF)
  {
    hal_usb_sof_irq();
  }
  if(regVal & USB_ISTR_ESOF)
  {
    hal_usb_esof_irq();
  }  
}

static void hal_usb_ctrm_irq()
{
  uint8_t epindex;
  /* stay in loop while pending interrupts */
  while ((USB->ISTR & USB_ISTR_CTR) != 0U)
  {
    /* extract highest priority endpoint number */
    epindex = (uint8_t)(USB->ISTR & USB_ISTR_EP_ID);

    if (epindex == 0U)
    {
        ep0_func();
    }else if(epindex == 1)
    {
        ep1_func();
    }
  }
}

static void hal_usb_reset_irq()
{
    uint16_t i = 0;
    uint16_t wEpRegVal = 0;
    USB->ISTR &= ~((uint16_t)(USB_ISTR_RESET));
    for(i=0;i<usb_obj.ep_count;i++)
    {
        USB_SET_ENDPOINT(usb_obj.ep_list[i].ep_idx,0U);
        wEpRegVal = USB_GET_ENDPOINT(usb_obj.ep_list[i].ep_idx);
        USB_SET_ENDPOINT(usb_obj.ep_list[i].ep_idx,wEpRegVal);

        wEpRegVal = USB_GET_ENDPOINT(usb_obj.ep_list[i].ep_idx);
        wEpRegVal |= (usb_obj.ep_list[i].ep_idx & USB_EPADDR_FIELD_Msk);
        USB_SET_ENDPOINT(usb_obj.ep_list[i].ep_idx, wEpRegVal);

        wEpRegVal = USB_GET_ENDPOINT(usb_obj.ep_list[i].ep_idx);
        wEpRegVal |= usb_obj.ep_list[i].ep_type;
        USB_SET_ENDPOINT(usb_obj.ep_list[i].ep_idx, wEpRegVal);

        USB_SET_EP_TX_ADDR(usb_obj.ep_list[i].ep_idx, usb_obj.ep_list[i].in_buf_addr);
        USB_SET_EP_TX_COUNT(usb_obj.ep_list[i].ep_idx, 0U);
        USB_SET_EP_RX_ADDR(usb_obj.ep_list[i].ep_idx, usb_obj.ep_list[i].out_buf_addr);
        USB_SET_EP_RX_COUNT(usb_obj.ep_list[i].ep_idx, 0U);

        if(i==0)
        {
          USB_SET_EP_RX_COUNT(usb_obj.ep_list[i].ep_idx, ((1U<<10)|(1U<<15)));
        }

        wEpRegVal = USB_GET_ENDPOINT(usb_obj.ep_list[i].ep_idx);
        wEpRegVal |= usb_obj.ep_list[i].in_buf_status;
        wEpRegVal |= usb_obj.ep_list[i].out_buf_status;
        USB_SET_ENDPOINT(usb_obj.ep_list[i].ep_idx,wEpRegVal);
    }
    USB->DADDR = (uint16_t)USB_DADDR_EF;
}

static void hal_usb_err_irq()
{
    USB->ISTR &= ~((uint16_t)(USB_ISTR_ERR)); 
}

static void hal_usb_wkup_irq()
{   
    USB->CNTR &= (uint16_t) ~(USB_CNTR_LP_MODE);
    USB->CNTR &= (uint16_t) ~(USB_CNTR_FSUSP);
    /* Clear Wakeup Flag */
    USB->ISTR &= ~((uint16_t)(USB_ISTR_WKUP));
}

static void hal_usb_susp_irq()
{
    /* FORCE RESET */
    USB->CNTR |= (uint16_t)(USB_CNTR_FRES);
    /* CLEAR RESET */
    USB->CNTR &= (uint16_t)(~USB_CNTR_FRES);
    /* wait for reset flag in ISTR */
    while ((USB->ISTR & USB_ISTR_RESET) == 0U){}
    /* Clear Reset Flag */
    USB->ISTR &= ~((uint16_t)(USB_ISTR_RESET));
    /* Force low-power mode in the macrocell */
    USB->CNTR |= (uint16_t)USB_CNTR_FSUSP;
    /* clear of the ISTR bit must be done after setting of CNTR_FSUSP */
    USB->ISTR &= ~((uint16_t)(USB_ISTR_SUSP));
    USB->CNTR |= (uint16_t)USB_CNTR_LP_MODE;
}

static void hal_usb_sof_irq()
{
    USB->ISTR &= ~((uint16_t)(USB_ISTR_SOF));
}

static void hal_usb_esof_irq()
{
    USB->ISTR &= ~((uint16_t)(USB_ISTR_ESOF));
}


static uint8_t usb_dev_addr = 0;
static uint8_t usb_ep0_buffer[64] = {0};
static void usb_ep0_setup(void);
static void ep0_func()
{
#define EP_IDX0  0
    uint32_t count = 0;
    if ((USB->ISTR & USB_ISTR_DIR) == 0U)
    {
        usb_clear_eptx_flag(EP_IDX0);
        usb_set_eprx_status(EP_IDX0,USB_EP_RX_VALID);
        if(usb_dev_addr > 0)
        {
        USB->DADDR = (uint16_t)(usb_dev_addr |USB_DADDR_EF);
        usb_dev_addr = 0;
        }
    }
    else
    {
        usb_clear_eprx_flag(EP_IDX0);

        count = USB_GET_EP_RX_COUNT(EP_IDX0) & 0x3ffU;

        if(count > 0)
        {
            usb_read_ep_buf(usb_ep0_buffer,usb_obj.ep_list[0].out_buf_addr,count);
            usb_ep0_setup();
            usb_set_eptx_status(EP_IDX0,USB_EP_TX_VALID);
        }
        else
        {
            usb_set_eprx_status(EP_IDX0,USB_EP_RX_VALID);
        }
    }
}

static void usb_ep0_setup(void)
{
  uint8_t *buf = 0;
  uint8_t len = 0;
  /* get device descriptor */
  if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[3] == 0x01))
  {
    buf = (uint8_t *)DeviceDescriptor;
    len = (uint8_t)USB_DES_DEVICE_LEN;
  }
  /* get configuration descriptor */
  else if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[3] == 0x02))
  {
    buf = (uint8_t *)ConfigDescriptor;
    len = (uint8_t)USB_DES_CFG_LEN;
  }
  /* get string descriptor */
  else if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[2] == 0x00)&&(usb_ep0_buffer[3] == 0x03))
  {
    buf = (uint8_t *)StringLangID;
    len = (uint8_t)USB_DES_STRING_LEN;
  }
  else if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[2] == 0x01)&&(usb_ep0_buffer[3] == 0x03))
  {
    buf = (uint8_t *)CustomHID_StringVendor;
    len = (uint8_t)USB_DES_VENDOR_LEN;
  }
  else if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[2] == 0x02)&&(usb_ep0_buffer[3] == 0x03))
  {
    buf = (uint8_t *)CustomHID_StringProduct;
    len = (uint8_t)USB_DES_PRODUCT_LEN;
  }
  else if((usb_ep0_buffer[0] == 0x80)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[2] == 0x03)&&(usb_ep0_buffer[3] == 0x03))
  {
    buf = (uint8_t *)CustomHID_StringSerial;
    len = (uint8_t)USB_DES_SERIAL_LEN;
  }
  /* get report descriptor */
  else if((usb_ep0_buffer[0] == 0x81)&&(usb_ep0_buffer[1] == 0x06)&&(usb_ep0_buffer[3] == 0x22))
  {
    buf = (uint8_t *)ReportDescriptor;
    len = (uint8_t)USB_DES_REPORT_LEN;
  }
  /* set address */
  else if((usb_ep0_buffer[0] == 0x00)&&(usb_ep0_buffer[1] == 0x05))
  {
    usb_dev_addr = usb_ep0_buffer[2];
  }
  /* other */
  else
  {
    /* do nothing */
    len = 0;
  }
  len = MIN(len, usb_ep0_buffer[6]);
  USB_SET_EP_TX_COUNT(0,len);
  usb_write_ep_buf(buf,usb_obj.ep_list[0].in_buf_addr,len);
}


uint8_t usb_ep1_buffer[16] = {0};
extern void usb_hid_callback(void);
static void ep1_func()
{

#define EP_IDX1  1
    uint32_t i = 0;
    if ((USB->ISTR & USB_ISTR_DIR) == 0U)
    {
      usb_clear_eptx_flag(EP_IDX1);
      usb_hid_callback();
      usb_write_ep_buf(usb_ep1_buffer,usb_obj.ep_list[EP_IDX1].in_buf_addr,16);
      USB_SET_EP_TX_COUNT(1,16);
      usb_set_eptx_status(EP_IDX1,USB_EP_TX_VALID);
      for(i=0;i<16;i++)
      {
        usb_ep1_buffer[i] = 0U;
      }
    }
}
