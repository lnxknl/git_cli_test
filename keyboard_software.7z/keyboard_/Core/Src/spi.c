#include "spi.h"

#define PL_H        GPIOA->BSRR = GPIO_BSRR_BS4
#define PL_L        GPIOA->BRR = GPIO_BRR_BR4
#define CE_H        GPIOA->BSRR = GPIO_BSRR_BS7
#define CE_L        GPIOA->BRR = GPIO_BRR_BR7

void spi_init()
{
    /* Enable clock */
	RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;
	AFIO->MAPR &= ~AFIO_MAPR_SPI1_REMAP;
    /* NVIC Setting */
    NVIC_SetPriority(SPI1_IRQn,7);
    NVIC_EnableIRQ(SPI1_IRQn);
    /* GPIO */
	GPIOA->CRL &= ~GPIO_CRL_MODE4_Msk;
	GPIOA->CRL |= GPIO_CRL_MODE4;
	GPIOA->CRL &= ~GPIO_CRL_CNF4_Msk;

	GPIOA->CRL &= ~GPIO_CRL_MODE5_Msk;
	GPIOA->CRL |= GPIO_CRL_MODE5;
	GPIOA->CRL &= ~GPIO_CRL_CNF5_Msk;
	GPIOA->CRL |= GPIO_CRL_CNF5_1;

	GPIOA->CRL &= ~GPIO_CRL_MODE6_Msk;
	GPIOA->CRL &= ~GPIO_CRL_CNF6_Msk;
	GPIOA->CRL |= GPIO_CRL_CNF6_0;

	GPIOA->CRL &= ~GPIO_CRL_MODE7_Msk;
	GPIOA->CRL |= GPIO_CRL_MODE7;
	GPIOA->CRL &= ~GPIO_CRL_CNF7_Msk;
    /* GPIO */
    PL_H;
    CE_H;

	SPI1->CR1 = 0x00000000;
	SPI1->CR2 = 0x00000000;
	SPI1->CR1 |= SPI_CR1_MSTR;
    /* BR = 010 */
	SPI1->CR1 |= SPI_CR1_BR_1;
    /* recevie only */
    SPI1->CR1 |= SPI_CR1_RXONLY;
    /* 16 bit mode*/
    /* SPI1->CR1 |= SPI_CR1_DFF; */
    /* cpol 1 */
    SPI1->CR1 |= SPI_CR1_CPOL;
    /* 1 edge mode */
    SPI1->CR1 &= ~SPI_CR1_CPHA;

/*     SPI1->CR2 |= SPI_CR2_RXNEIE; */
    
    SPI1->CR2 |= SPI_CR2_SSOE;
    /* enable SPI */
	// SPI1->CR1 |= SPI_CR1_SPE;
}

void spi_receive(uint8_t *spi_buffer, uint8_t length) 
{
    __disable_irq();
    uint8_t i = 0;
    PL_L;
    __NOP();
    __NOP();
    PL_H;
    __NOP();
    __NOP();
    CE_L;
    __NOP();
    __NOP();
    SPI1->SR &= ~SPI_SR_RXNE;
    SPI1->CR1 |= SPI_CR1_SPE;
    spi_buffer[0] = (uint8_t)SPI1->DR;
    for(i=0;i<length;i++)
    {
        while(!(SPI1->SR & SPI_SR_RXNE)){}
        spi_buffer[i] = (uint8_t)SPI1->DR;
        SPI1->SR &= ~SPI_SR_RXNE;
    }
    SPI1->CR1 &= ~SPI_CR1_SPE;
    __NOP();
    __NOP();
    CE_H;
    __enable_irq();
}
