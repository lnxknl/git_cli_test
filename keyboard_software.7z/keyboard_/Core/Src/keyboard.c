#include "keyboard.h"
#include "hal_usb_core.h"
#include "spi.h"

#define     KEY_NUM         84U
#define     SPI_BUF_NUM     11U
#define     CONFIRM_COUNT   15U
#define     MAX_CONFIRM_CNT 20U

static const uint8_t key_remapping[KEY_NUM] = 
{
    /* 1-8 */ KEY_L_CTRL, KEY_L_SHIFT, KEY_L_ALT, KEY_L_GUI, KEY_R_CTRL, KEY_R_SHIFT, KEY_R_ALT, KEY_R_GUI,
    /* 9-16*/ KEY_CAPS_LOCK, KEY_A, KEY_S, KEY_D, KEY_F, KEY_C, KEY_X, KEY_Z,
    /*17-24*/ KEY_G, KEY_H, KEY_J, KEY_M, KEY_N, KEY_SPACEBAR, KEY_B, KEY_V,
    /*25-32*/ KEY_K, KEY_L, KEY_SEMICOLON, KEY_QUOTE, KEY_ENTER, KEY_SLASH, KEY_PERIOD, KEY_COMMA,
    /*33-40*/ KEY_BACKSLASH, KEY_END, KEY_PAGE_UP, KEY_UP_ARROW, KEY_PAGE_DOWN, KEY_RIGHT_ARROW, KEY_DOWN_ARROW, KEY_LEFT_ARROW,
    /*41-48*/ KEY_0, KEY_MINUS, KEY_EQUAL, KEY_BACKSPACE, KEY_HOME, KEY_RIGHT_BRACKET, KEY_LEFT_BRACKET, KEY_P,
    /*49-56*/ KEY_6, KEY_7, KEY_8, KEY_9, KEY_O, KEY_I, KEY_U, KEY_Y,
    /*57-64*/ KEY_2, KEY_3, KEY_4, KEY_5, KEY_T, KEY_R, KEY_E, KEY_W,
    /*65-72*/ KEY_ESCAPE, KEY_F1, KEY_F2, KEY_F3, KEY_1, KEY_Q, KEY_GRAVE_ACCENT, KEY_TAB,
    /*73-80*/ KEY_F4, KEY_F5, KEY_F6, KEY_F7, KEY_F8, KEY_F9, KEY_F10, KEY_F11,
    /*81-84*/ KEY_F12, KEY_NONE, KEY_INSERT, KEY_DELETE
};

volatile uint8_t key_buf[KEY_NUM] = {0};

void keyboard_handle()
{
    uint32_t i = 0;
    uint8_t spi_buffer[SPI_BUF_NUM] = {0};
    uint8_t spi_buf_count = 0;
    for(i=0;i<SPI_BUF_NUM;i++)
    {
        spi_buffer[i]=0xff;
    }

    for(;;)
    {
        spi_receive(spi_buffer, SPI_BUF_NUM);
        spi_buf_count = 0;
        for(i=0;i<KEY_NUM;i++)
        {
            if((spi_buffer[spi_buf_count] & (0x80>>(i%8))) == 0U)
            {
                if(key_buf[i] < MAX_CONFIRM_CNT)
                {
                    key_buf[i]++;
                }
            }
            else
            {
                if(key_buf[i] > 0)
                {
                    key_buf[i]--;
                } 
            }
            if(i%8==7)
            spi_buf_count++;
        }

    }
}

extern uint8_t usb_ep1_buffer[16];

void usb_hid_callback()
{
    uint8_t i = 0;
    uint8_t count = 0;
    count = 0;
    usb_ep1_buffer[count] = 0;
    for(i=0;i<8;i++)
    {
        if(key_buf[i] >= CONFIRM_COUNT)
        {
            usb_ep1_buffer[count] |= (uint8_t)(0x1<<i);
        }
    }
    count = 2;
    for(i=8;i<KEY_NUM;i++)
    {
        if(key_buf[i] >= CONFIRM_COUNT)
        {
            usb_ep1_buffer[count] = key_remapping[i];
            count++;
            if(count>=16)
            {
                break;
            }
        }
    }
}
