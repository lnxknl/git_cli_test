#include "hal_usb_descriptor.h"

const uint8_t DeviceDescriptor[USB_DES_DEVICE_LEN] =
{
    USB_DES_DEVICE_LEN,   /*bLength */
    0x01,   /*bDescriptorType*///描述符类型：0x01表示设备描述符
    0x00,   /*bcdUSB *///USB协议版本 2.0
    0x02,
    0x00,   /*bDeviceClass*///设备所使用的类代码，一般为0
    0x00,   /*bDeviceSubClass*///设备所使用的子类代码，类代码为0，子类代码也为0
    0x00,   /*bDeviceProtocol*///设备所使用的协议
    0x40,   /*bMaxPacketSize*///端点0最大包长，0x40,64个字节
    0x53,   /*idVendor*///VID 厂商ID
    0x05,
    0x01,   /*idProduct = 0x5750*///PID 产品ID，自定义
    0x00,
    0x00,   /*bcdDevice rel. 2.00*///产品版本号，自定义
    0x02,
    1,      /*Index of string descriptor describing manufacturer *///厂商字符串描述符索引值，如果没有则为0                                             
    2,      /*Index of string descriptor describing product *///产品字符串描述符索引值	                                             
    3,      /*Index of string descriptor describing the device serial number *///设备序列号字符串索引值
                                             
    0x01,   /*bNumConfigurations*///表示支持多少种配置
};

const uint8_t ConfigDescriptor[USB_DES_CFG_LEN] =
{
    /* Configuation Descriptor */
    USB_DES_CONFIGURATION_LEN,   /* bLength: Configuation Descriptor size */
    0x02,   /* bDescriptorType: Configuration *///描述符类型：配置描述符为0x02
    0x29,   /* wTotalLength: Bytes returned *///配置描述符集合总长度     
    0x00,
    0x01,   /* bNumInterfaces: 1 interface *///表示该配置所支持的接口数量
    0x01,   /* bConfigurationValue: Configuration value *///表示该配置集合的配置值，在设置配置请求中，主机会发送对应的配置值，表示设置了该配置
    0,      /* iConfiguration: Index of string descriptor describing the configuration*///配置字符串索引                                  
    0xC0,   /* bmAttributes: Bus powered *//*Bus powered: 7th bit, Self Powered: 6th bit, Remote wakeup: 5th bit, reserved: 4..0 bits *///描述设备特性    
    0x96,   /* MaxPower 300 mA: this current is used for detecting Vbus *///设备需要的最大电流

    /* Interface Descriptor */
    USB_DES_INTERFACE_LEN,   /* bLength: Interface Descriptor size *///描述符长度
    0x04,   /* bDescriptorType: Interface descriptor type *///描述符类型：0x03表示接口描述符
    0x00,   /* bInterfaceNumber: Number of Interface *///表示该接口的编号，从0开始递增
    0x00,   /* bAlternateSetting: Alternate setting *///表示该接口的备用接口编号，从0开始递增
    0x01,   /* bNumEndpoints *///该接口使用的非0端点的端点数
    0x03,   /* bInterfaceClass: HID *///该接口所使用的类
    0x01,   /* bInterfaceSubClass : 1=BOOT, 0=no boot *///该接口所使用的子类
    0x01,   /* nInterfaceProtocol : 0=none, 1=keyboard, 2=mouse *///该接口所使用的协议
    0,      /* iInterface: Index of string descriptor *///接口描述符索引

	/* HID Descriptor */
    USB_DES_HID_LEN,   /* bLength: HID Descriptor size *///描述符长度
    0x21,   /* bDescriptorType: HID *///描述符类型：0x21表示HID描述符
    0x10,   /* bcdHID: HID Class Spec release number *///HID协议版本号 1.1
    0x01,
    0x00,   /* bCountryCode: Hardware target country *///国家代码
    0x01,   /* bNumDescriptors: Number of HID class descriptors to follow *///下级描述符数量
    0x22,   /* bDescriptorType *///下级描述符类型：0x22表示报告描述符
    USB_DES_REPORT_LEN,/* wItemLength: Total length of Report descriptor *///报告描述符长度
    0x00,

	/* Endpoint Descriptor */
    USB_DES_ENDPOINT_LEN,   /* bLength: Endpoint Descriptor size */
    0x05,   /* bDescriptorType: *///描述符类型:0x05表示端点描述符
    0x81,   /* bEndpointAddress: Endpoint Address (IN) *///该端点地址：方向+端点号，端点2输入
    // bit 3...0 : the endpoint number
    // bit 6...4 : reserved
    // bit 7     : 0(OUT), 1(IN)
    0x03,   /* bmAttributes: Interrupt endpoint *///该端点属性
    0x40,   /* wMaxPacketSize: 64 Bytes max *///该端点支持的最大包长度
    0x00,
    0x04,   /* bInterval: Polling Interval (4 ms) *///端点查询时间
};

/* String */
const uint8_t StringLangID[USB_DES_STRING_LEN] =
{
    USB_DES_STRING_LEN,   /* bLength: LanguageID Descriptor size */
    0x03,   /* bDescriptorType: LanguageID */
    0x09,   /* 0x0409 表示美式英语 */
    0x04
};

const uint8_t CustomHID_StringVendor[USB_DES_VENDOR_LEN] = 
{
  USB_DES_VENDOR_LEN,
  0x03,
  'S',0,'T',0,'M',0,'i',0,'c',0,'r',0,'o',0,'e',0,'l',0,'e',0,'c',0,'t',0,'r',0,'o',0,'n',0,'i',0,'c',0,'s',0
};

const uint8_t CustomHID_StringProduct[USB_DES_PRODUCT_LEN] = 
{
  USB_DES_PRODUCT_LEN,
  0x03,
  'K',0,'e',0,'y',0,'b',0,'o',0,'a',0,'r',0,'d',0
};

const uint8_t CustomHID_StringSerial[USB_DES_SERIAL_LEN] = 
{
  USB_DES_SERIAL_LEN,
  0x03,
  '2',0,'0',0,'2',0,'3',0,'0',0,'3',0,'1',0,'2',0
};

const uint8_t ReportDescriptor[USB_DES_REPORT_LEN] =
{
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x06,                    // USAGE (Keyboard)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x05, 0x07,                    //   USAGE_PAGE (Keyboard)
    0x19, 0xe0,                    //   USAGE_MINIMUM (Keyboard LeftControl)
    0x29, 0xe7,                    //   USAGE_MAXIMUM (Keyboard Right GUI)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x08,                    //   REPORT_COUNT (8)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x81, 0x03,                    //   INPUT (Cnst,Var,Abs)
    0x95, 0x0E,                    //   REPORT_COUNT (14)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x64,                    //   LOGICAL_MAXIMUM (100)
    0x05, 0x07,                    //   USAGE_PAGE (Keyboard)
    0x19, 0x00,                    //   USAGE_MINIMUM (Reserved (no event indicated))
    0x29, 0x65,                    //   USAGE_MAXIMUM (Keyboard Application)
    0x81, 0x00,                    //   INPUT (Data,Ary,Abs)
    0xc0                           // END_COLLECTION
};



