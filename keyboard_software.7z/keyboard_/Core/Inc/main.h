
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif


#include "stm32f103x6.h"


#ifdef __cplusplus
}
#endif

#endif
