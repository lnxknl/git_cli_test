#ifndef SPI_H
#define SPI_H

#include "stm32f103x6.h"

void spi_init(void);
void spi_receive(uint8_t *spi_buffer, uint8_t length);

#endif