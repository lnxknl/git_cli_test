#ifndef KEYBOARD_H
#define KEYBOARD_H


typedef enum
{
    KEY_NONE = 0,          // 无按键
    KEY_A = 4,             // A键
    KEY_B = 5,             // B键
    KEY_C = 6,             // C键
    KEY_D = 7,             // D键
    KEY_E = 8,             // E键
    KEY_F = 9,             // F键
    KEY_G = 10,            // G键
    KEY_H = 11,            // H键
    KEY_I = 12,            // I键
    KEY_J = 13,            // J键
    KEY_K = 14,            // K键
    KEY_L = 15,            // L键
    KEY_M = 16,            // M键
    KEY_N = 17,            // N键
    KEY_O = 18,            // O键
    KEY_P = 19,            // P键
    KEY_Q = 20,            // Q键
    KEY_R = 21,            // R键
    KEY_S = 22,            // S键
    KEY_T = 23,            // T键
    KEY_U = 24,            // U键
    KEY_V = 25,            // V键
    KEY_W = 26,            // W键
    KEY_X = 27,            // X键
    KEY_Y = 28,            // Y键
    KEY_Z = 29,            // Z键
    KEY_1 = 30,            // 1键（数字1）
    KEY_2 = 31,            // 2键（数字2）
    KEY_3 = 32,            // 3键（数字3）
    KEY_4 = 33,            // 4键（数字4）
    KEY_5 = 34,            // 5键（数字5）
    KEY_6 = 35,            // 6键（数字6）
    KEY_7 = 36,            // 7键（数字7）
    KEY_8 = 37,            // 8键（数字8）
    KEY_9 = 38,            // 9键（数字9）
    KEY_0 = 39,            // 0键（数字0）
    KEY_ENTER = 40,        // 回车键
    KEY_ESCAPE = 41,       // ESC键
    KEY_BACKSPACE = 42,    // 退格键
    KEY_TAB = 43,          // Tab键
    KEY_SPACEBAR = 44,     // 空格键
    KEY_MINUS = 45,        // 减号键
    KEY_EQUAL = 46,        // 等号键
    KEY_LEFT_BRACKET = 47, // 左中括号键
    KEY_RIGHT_BRACKET = 48,// 右中括号键
    KEY_BACKSLASH = 49,    // 反斜杠键
    KEY_NON_US_HASH = 50,  // 非美式英语键盘上的#键（位于Enter下方）
    KEY_SEMICOLON = 51,    // 分号键
    KEY_QUOTE = 52,        // 引号键
    KEY_GRAVE_ACCENT = 53, // 撇号键
    KEY_COMMA = 54,        // 逗号键
    KEY_PERIOD = 55,       // 句点键
    KEY_SLASH = 56,        // 斜杠键
    KEY_CAPS_LOCK = 57,    // 大写锁定键
    KEY_F1 = 58,           // F1键
    KEY_F2 = 59,           // F2键
    KEY_F3 = 60,           // F3键
    KEY_F4 = 61,           // F4键
    KEY_F5 = 62,           // F5键
    KEY_F6 = 63,           // F6键
    KEY_F7 = 64,           // F7键
    KEY_F8 = 65,           // F8键
    KEY_F9 = 66,           // F9键
    KEY_F10 = 67,          // F10键
    KEY_F11 = 68,          // F11键
    KEY_F12 = 69,          // F12键
    KEY_PRINT_SCREEN = 70,         // Print Screen键
    KEY_SCROLL_LOCK = 71,          // Scroll Lock键
    KEY_PAUSE = 72,                // Pause键
    KEY_INSERT = 73,               // Insert键
    KEY_HOME = 74,                 // Home键
    KEY_PAGE_UP = 75,              // Page Up键
    KEY_DELETE = 76,               // Delete键
    KEY_END = 77,                  // End键
    KEY_PAGE_DOWN = 78,            // Page Down键
    KEY_RIGHT_ARROW = 79,          // 右箭头键
    KEY_LEFT_ARROW = 80,           // 左箭头键
    KEY_DOWN_ARROW = 81,           // 下箭头键
    KEY_UP_ARROW = 82,             // 上箭头键
    KEYPAD_NUM_LOCK = 83,          // 数字键盘Num Lock键
    KEYPAD_SLASH = 84,             // 数字键盘斜杠键
    KEYPAD_ASTERISK = 85,          // 数字键盘星号键
    KEYPAD_MINUS = 86,             // 数字键盘减号键
    KEYPAD_PLUS = 87,              // 数字键盘加号键
    KEYPAD_ENTER = 88,             // 数字键盘回车键
    KEYPAD_1 = 89,                 // 数字键盘数字1键
    KEYPAD_2 = 90,                 // 数字键盘数字2键
    KEYPAD_3 = 91,                 // 数字键盘数字3键
    KEYPAD_4 = 92,                 // 数字键盘数字4键
    KEYPAD_5 = 93,                 // 数字键盘数字5键
    KEYPAD_6 = 94,                 // 数字键盘数字6键
    KEYPAD_7 = 95,                 // 数字键盘数字7键
    KEYPAD_8 = 96,                 // 数字键盘数字8键
    KEYPAD_9 = 97,                 // 数字键盘数字9键
    KEYPAD_0 = 98,                 // 数字键盘数字0键
    KEYPAD_PERIOD = 99,            // 数字键盘句点键
    KEY_L_CTRL  = 0xE0,
    KEY_L_SHIFT = 0xE1,
    KEY_L_ALT   = 0xE2,
    KEY_L_GUI   = 0xE3,
    KEY_R_CTRL  = 0xE4,
    KEY_R_SHIFT = 0xE5,
    KEY_R_ALT   = 0xE6,
    KEY_R_GUI   = 0xE7
}KeyName_TypeDef;

void keyboard_handle(void);
void usb_hid_callback(void);

#endif