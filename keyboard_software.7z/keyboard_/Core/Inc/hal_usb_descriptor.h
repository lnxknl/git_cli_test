#ifndef _HAL_USB_DESCRIPTOR_H_
#define _HAL_USB_DESCRIPTOR_H_

#include "stdint.h"

#define USB_DES_DEVICE_LEN                  (uint32_t)(18)

#define USB_DES_CONFIGURATION_LEN           (uint32_t)(9)
#define USB_DES_INTERFACE_LEN               (uint32_t)(9)
#define USB_DES_HID_LEN                     (uint32_t)(9)
#define USB_DES_ENDPOINT_LEN                (uint32_t)(7)
#define USB_DES_CFG_LEN                     (uint32_t)(USB_DES_CONFIGURATION_LEN    \
                                                        +USB_DES_INTERFACE_LEN      \
                                                        +USB_DES_HID_LEN            \
                                                        +USB_DES_ENDPOINT_LEN)

#define USB_DES_STRING_LEN                  (uint32_t)(4)

#define USB_DES_VENDOR_LEN                  (uint32_t)(38)

#define USB_DES_PRODUCT_LEN                 (uint32_t)(18)

#define USB_DES_SERIAL_LEN                  (uint32_t)(18)

#define USB_DES_REPORT_LEN                  (uint32_t)(45)


extern const uint8_t DeviceDescriptor[USB_DES_DEVICE_LEN];
extern const uint8_t ConfigDescriptor[USB_DES_CFG_LEN];
extern const uint8_t StringLangID[USB_DES_STRING_LEN];
extern const uint8_t CustomHID_StringVendor[USB_DES_VENDOR_LEN];
extern const uint8_t CustomHID_StringProduct[USB_DES_PRODUCT_LEN];
extern const uint8_t CustomHID_StringSerial[USB_DES_SERIAL_LEN];
extern const uint8_t ReportDescriptor[USB_DES_REPORT_LEN];


#endif
