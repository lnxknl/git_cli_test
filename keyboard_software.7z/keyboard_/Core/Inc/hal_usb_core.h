#ifndef _HAL_USB_CORE_H_
#define _HAL_USB_CORE_H_

#include "stm32f103x6.h"



#define MIN(x,y) (((x) < (y)) ? (x) : (y) )
#define MAX(x,y) (((x) > (y)) ? (x) : (y) )


#define USB_GET_ENDPOINT(epNum)             (*(volatile uint16_t *)(&USB->EP0R + ((epNum) * 2U)))
#define USB_SET_ENDPOINT(epNum, wRegValue)  (*(volatile uint16_t *)(&USB->EP0R + ((epNum) * 2U)) = (volatile uint16_t)(wRegValue))


#define USB_SET_EP_TX_ADDR(epNum, wRegValue)    (*(volatile uint16_t *)((epNum*8+0)*2 + USB_PMAADDR) = (volatile uint16_t)wRegValue)
#define USB_SET_EP_TX_COUNT(epNum, wRegValue)    (*(volatile uint16_t *)((epNum*8+2)*2 + USB_PMAADDR) = (volatile uint16_t)wRegValue)
#define USB_SET_EP_RX_ADDR(epNum, wRegValue)    (*(volatile uint16_t *)((epNum*8+4)*2 + USB_PMAADDR) = (volatile uint16_t)wRegValue)
#define USB_SET_EP_RX_COUNT(epNum, wRegValue)    (*(volatile uint16_t *)((epNum*8+6)*2 + USB_PMAADDR) = (volatile uint16_t)wRegValue)
#define USB_GET_EP_RX_COUNT(epNum)               (*(volatile uint16_t *)((epNum*8+6)*2 + USB_PMAADDR))

typedef struct
{
    uint32_t ep_idx;
    uint32_t ep_type;
    uint32_t in_buf_status;
    uint32_t in_buf_addr;
    uint32_t out_buf_status;
    uint32_t out_buf_addr;
}usb_ep_t; /* endpoint */

typedef struct
{
    uint32_t ep_count;
    usb_ep_t *ep_list;
}usb_obj_t;



void hal_usb_init(void);


#endif